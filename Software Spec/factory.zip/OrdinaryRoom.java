

public class OrdinaryRoom implements Room {
	
	private Room room;
	
	public OrdinaryRoom() {
		System.out.println("Ordinary Room");
	}
	
	@Override
	public void connect(Room room) {
		this.room = room;
	}

}
