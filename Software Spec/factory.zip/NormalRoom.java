
public class NormalRoom {

}
