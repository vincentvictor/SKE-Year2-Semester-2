
public interface Room {
	public void connect(Room room);
}
