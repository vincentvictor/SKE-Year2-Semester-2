package Memento;

public class Originator {
	private String state;
	
	public void setStrate(String state) {
		this.state = state;
	}
	
	public Memento saveState() {
		return new Memento(state);
	}
	
	public void restoreState(Memento memento) {
		this.state = memento.getSavedState();
	}
	
	public void printState() {
		System.out.println(this.state);
	}
	
	public static class Memento {
		private String savedState;
		public Memento(String state) {
			savedState = state;
		}
		public String getSavedState() {
			return savedState;
		}
	}
	
	public static void main(String[] args) {
		Originator o =new Originator();
		
	}
}
