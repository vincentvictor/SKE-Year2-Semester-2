#include <stdio.h> 

void main() 
{ 
int i,sum=0; 
for (i=0; i < 100000; i++) 
sum += i; 
}

