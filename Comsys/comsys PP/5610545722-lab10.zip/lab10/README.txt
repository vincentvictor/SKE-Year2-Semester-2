PS. mytest is loop and test2 is matrix

